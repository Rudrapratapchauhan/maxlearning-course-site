SITEURL = 'https://yourusername.github.io/maxlearning-course-site'
RELATIVE_URLS = False
