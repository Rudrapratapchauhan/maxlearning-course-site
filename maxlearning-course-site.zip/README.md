# MaxLearning – Static Course Website

Python-based static course website built using Pelican.
